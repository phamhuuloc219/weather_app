import 'package:flutter/foundation.dart' show immutable;

@immutable
class Constants {
  static const String apiKey = 'd335166a967afc1b69dd9809a929a584';
}
